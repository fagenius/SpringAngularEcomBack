package com.test.TestDevoir;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestDevoirApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestDevoirApplication.class, args);
	}

}
