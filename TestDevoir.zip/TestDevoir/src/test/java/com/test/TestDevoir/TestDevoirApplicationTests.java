package com.test.TestDevoir;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestDevoirApplicationTests {

	@Test
	void contextLoads() {
	}

}
