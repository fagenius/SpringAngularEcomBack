package com.isi.Devoir;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevoirApplicationTests {

	@Test
	void contextLoads() {
	}

}
