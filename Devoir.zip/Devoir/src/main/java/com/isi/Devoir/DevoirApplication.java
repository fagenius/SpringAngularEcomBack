package com.isi.Devoir;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevoirApplication {

	public static void main(String[] args) {
		SpringApplication.run(DevoirApplication.class, args);
	}

}
