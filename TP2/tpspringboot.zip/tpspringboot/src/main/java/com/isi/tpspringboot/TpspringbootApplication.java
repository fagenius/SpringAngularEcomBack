package com.isi.tpspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TpspringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(TpspringbootApplication.class, args);
	}

}
